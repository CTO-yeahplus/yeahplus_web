여기에 seam-detonation.gif 와 prop-break.gif 를 넣고 다시 zip 하세요 (make_presskit.sh 실행)
