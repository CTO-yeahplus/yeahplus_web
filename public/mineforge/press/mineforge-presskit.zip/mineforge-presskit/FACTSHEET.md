# Mineforge: Sweeper Roguelike — Fact Sheet

**Developer** YeahPlus Co., Ltd. — solo developer, Seoul, Korea
**Contact** cto@yeahplus.co.kr
**Release** August 2026, worldwide
**Platform** iPhone, iOS 15.0 or later · 10.9 MB
**Price** $2.99 (launch price) · no ads · no in-app purchases · no subscription
**Languages** English, Korean
**Genre** Puzzle / Roguelike deckbuilder
**App Store** https://apps.apple.com/us/app/mineforge-sweeper-roguelike/id6802883164
**Website** https://www.yeahplus.co.kr/mineforge/
**Age rating** 4+
**Privacy** Data Not Collected — the app makes no network calls of any kind

---

## One line

Minesweeper deduction, rebuilt as a roguelike run where your deck is buried in the level.

## One paragraph

Mineforge keeps classic minesweeper deduction intact and builds a run around it. Every
dig scores, and a dig adjacent to your previous one raises a seam multiplier that resets
the moment you break the chain — so the decision stops being "which tile is safe" and
becomes "is this safe tile worth my chain". Mines break pit props instead of ending the
game, leaving craters that recalculate the numbers around them. Between rounds you buy
charms and load ore into a satchel, and that ore is then salted into your next board as
treasure, glinting under the dirt. Eight chapters, a boss every third round that rewrites
one rule, then Endless.

---

## Features

- **Seam scoring** — chained digs raise a multiplier; disconnected digs reset it to zero
- **Pit props** — mines break a prop and leave a crater; surrounding numbers recalculate
- **Guaranteed safe first dig** on every board
- **Solver-based canary** — hints only tiles that are provably safe; its silence means the board truly requires a guess
- **Ore as deck** — 7 stone types buried into your next board as visible treasure
- **45 charms**, 16 unlocked through play
- **8 bosses**, each bending one rule for a whole round
- **6 quarry layouts**, 5 starting satchels, 3 difficulties, permanent upgrades between runs
- **Daily and weekly seeded boards** — everyone digs the same minefield
- **Game Center** — 3 leaderboards, 15 achievements (entirely optional)
- **4 visual themes** with per-theme music

---

## Development notes (usable as quotes)

> "The board is checked by a solver before it's dealt. If the solver can't open it by
> deduction, the board doesn't get used."

> "The hint isn't a reveal — it's a constraint solver. It only sings over a tile logic
> guarantees. When it goes quiet, that silence is information: you're genuinely at a
> guess, and the game is telling you so."

> "I cut an objective called 'resonance' — clear pairs of adjacent equal numbers. It read
> as a deduction goal but the numbers are hidden until you dig, so it was pure luck in a
> deduction costume. It was the number one cause of death in bot testing."

> "I balanced it with a bot that plays using the same solver and guesses only at minimum
> risk. Early on it won 95% of runs, because clearing the board was an instant win and the
> score quota was decorative. Making the quota the only win condition dropped it to zero
> overnight, and finding out why took longer than building the shop."

---

## Screenshots & GIFs

`screenshots/` — 5 English and 5 Korean, 1290×2796
`gifs/seam-detonation.gif` — a 12-link seam paying out
`gifs/prop-break.gif` — hitting a mine, losing a prop, numbers recalculating around the crater

All assets free to use in coverage.
